import java.io.*;
import java.util.*;

public class metaData {
    public static final String file = "metadata.csv";

    public static String saveMetadata(Table table) {
        StringBuilder tableMetadata = new StringBuilder();
        try {
            metaData.clearMetadataFile();
            
            FileWriter fw = new FileWriter(file, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);

            // Append header to the metadata string
            tableMetadata.append("Table Name, Column Name, Column Type, ClusteringKey, IndexName, IndexType \r\n");

            Hashtable<String, String> colNameType = table.getColNameType();
            ArrayList<String> columnNames = new ArrayList<>(colNameType.keySet());

            int size = columnNames.size();
            for (int i = 0; i < size; i++) {
                String colName = columnNames.get(i);
                tableMetadata.append(table.getTableName()).append(", ");
                tableMetadata.append(colName).append(", ");
                tableMetadata.append(colNameType.get(colName)).append(", ");
                if (colName.equals(table.clusteringKeyColumn)) {
                    tableMetadata.append("True, ");
                } else {
                    tableMetadata.append("False, ");
                }
                Set<String> keys = table.indexNames.keySet();
                String[] keysArray = keys.toArray(new String[0]);
                boolean flag = false;
                for (int j = 0; j < keysArray.length; j++) {
                    if (keysArray[j].equals(colName)) {
                        flag = true;
                        break;
                    }
                }
                if (flag) {
                    tableMetadata.append(table.indexNames.get(colName)).append(", B+Tree \n");
                } else {
                    tableMetadata.append("Null, Null \n");
                }
            }

            // Write metadata string to file
            pw.print(tableMetadata.toString());

            // Close resources
            pw.close();
            bw.close();
            fw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tableMetadata.toString();
    }

    
    public static void clearMetadataFile() {
        try (FileWriter writer = new FileWriter(file);
             PrintWriter out = new PrintWriter(writer)) {
            out.print(""); // Truncate the file by writing an empty string
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
        public static void main(String[] args) {
        }
    }