import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

public class Tuple implements Serializable {
    public Hashtable<String, Object> values;

    public Hashtable<String, Object> getValues() {
		return values;
	}

	public void setValues(Hashtable<String, Object> values) {
		this.values = values;
	}

	public Tuple(Hashtable<String, Object> values) {
        this.values = values;
    }

    public Object getClusteringKeyValue(String clustringKeyTable) {
        return (Object) values.get(clustringKeyTable);
    }

    public void updateValues(Hashtable<String, Object> newValues, String clusteringKey) {
    	Hashtable<String, Object> newHash = new Hashtable<String, Object>();
    	
    	for(int i=0; i<values.keySet().toArray().length; i++) {
    		String x = (String) values.keySet().toArray()[i];
    		boolean flag = false;
    		for(int j=0; j<newValues.keySet().toArray().length; j++) {
    			String y = (String) newValues.keySet().toArray()[j];
    			if(x.equals(y)) {
    				flag = true;
    			}
    		}
    		if(flag==true) {
    			Object obj = newValues.get(x);
    			newHash.put(x, obj);
    		}
    		else {
    			newHash.put(x, values.get(x));
    		}
    	}
    	values.clear();
    	values.putAll(newHash);
    }

    public boolean matchesCriteria(Hashtable<String, Object> htblColNameValue) {
        for (int i = 0; i < htblColNameValue.size(); i++) {
            String key = (String) htblColNameValue.keySet().toArray()[i];
            if (!values.containsKey(key) || !values.get(key).equals(htblColNameValue.get(key))) {
                return false;
            }
        }
        return true;
    }
    
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        Enumeration<String> keys = values.keys();
        while (keys.hasMoreElements()) {
            String key = keys.nextElement();
            Object value = values.get(key);
            sb.append(key).append("=").append(value);
            if (keys.hasMoreElements()) {
                sb.append(", ");
            }
        }
        sb.append("}");
        return sb.toString();
    }


}
