


public class DBAppException extends Exception {


	public DBAppException( String strMessage ){
		super( strMessage );
	}
	

}