import java.io.InputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Vector;

public class Page implements Serializable {
    public Vector<Object> tuples;
    public static final String CONFIG_FILE = "DBApp.config";
    
    public Page() {
        this.tuples = new Vector<>();
    }

    public Vector<Object> getTuples() {
		return tuples;
	}

	public void setTuples(Vector<Object> tuples) {
		this.tuples = tuples;
	}
	
    public static int getMaximumRowsCountinPage() {
        try (InputStream inputStream = Page.class.getClassLoader().getResourceAsStream(CONFIG_FILE)) {
            if (inputStream == null) {
                throw new RuntimeException("Unable to find " + CONFIG_FILE);
            }

            Properties properties = new Properties();
            properties.load(inputStream);

            String maxRowsStr = properties.getProperty("MaximumRowsCountinPage");
            if (maxRowsStr == null) {
                throw new RuntimeException("MaximumRowsCountinPage parameter is missing in " + CONFIG_FILE);
            }

            return Integer.parseInt(maxRowsStr);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

	public boolean isFull() {
        return tuples.size() == this.getMaximumRowsCountinPage();
    }
	
	public boolean isEmpty() {
		return tuples.size()==0;
	}

    public void insertTuple(Hashtable<String, Object> htblColNameValue, Table table)  {
        Tuple newTuple = new Tuple(htblColNameValue);
        tuples.add(newTuple);
        ArrangeTuples(tuples, table);
    }
    
    public void ArrangeTuples(Vector<Object> tuples, Table table) {
        for (int i = 0; i < tuples.size() - 1; i++) {
            for (int j = 0; j < tuples.size() - i - 1; j++) {
                Tuple current = (Tuple) tuples.get(j);
                Tuple next = (Tuple) tuples.get(j + 1);
                if (current.getClusteringKeyValue("table.clusteringKeyColumn") instanceof Integer) {
                	if((int)current.getClusteringKeyValue(table.clusteringKeyColumn) > (int)next.getClusteringKeyValue("table.clusteringKeyColumn")) {
                		tuples.set(j, next);
                        tuples.set(j + 1, current);
                	}  
                }
                if(current.getClusteringKeyValue("table.clusteringKeyColumn") instanceof Double) {
                	if((double)current.getClusteringKeyValue("table.clusteringKeyColumn") > (double)next.getClusteringKeyValue("table.clusteringKeyColumn")) {
                		tuples.set(j, next);
                        tuples.set(j + 1, current);
                	}
                }
                if(current.getClusteringKeyValue("table.clusteringKeyColumn") instanceof String) {
                	if(((String)current.getClusteringKeyValue("table.clusteringKeyColumn")).compareTo((String) next.getClusteringKeyValue("table.clusteringKeyColumn")) >0) {
                		tuples.set(j, next);
                        tuples.set(j + 1, current);
                	}
                }
            }
        }
    }

    public Tuple getTupleByClusteringKey(String clusteringKeyValue, String clustringKeyTable) {
        for (int i = 0; i < tuples.size(); i++) {
            Tuple tuple = (Tuple) tuples.get(i);
            Object x = tuple.getClusteringKeyValue(clustringKeyTable);
            if (x instanceof Integer) {
                if((int)x == Integer.parseInt(clusteringKeyValue)) {
                    return tuple;
                }
            } else if (x instanceof Double) {
                if((double)x == Double.parseDouble(clusteringKeyValue)) {
                    return tuple;
                }
            } else if (x instanceof String) {
                if(x.toString().equals(clusteringKeyValue)) {
                    return tuple;
                }
            }
        }
        return null;
    }



    public boolean deleteTuples(Hashtable<String, Object> htblColNameValue) {
        for (int i = 0; i < tuples.size(); i++) {
            Tuple tuple = (Tuple) tuples.get(i);
            if (tuple.matchesCriteria(htblColNameValue)) {
                tuples.remove(i);
                return true;
            }
        }
        return false;
    }
    
    public String toStringPage() {
    	StringBuilder sb = new StringBuilder();
    	for(int i=0; i<this.getTuples().size(); i++) {
    		Tuple t = (Tuple) this.getTuples().get(i);
    		sb.append(t.toString()).append("\n");   		
    	}
    	return sb.toString();
    }
}
