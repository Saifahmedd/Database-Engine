import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Vector;

public class Table implements Serializable{
    public String tableName;
    public String clusteringKeyColumn;
    public Hashtable<String, String> colNameType;
    public ArrayList<Integer> pagesNumber;
    public static ArrayList<Table> tables = new ArrayList<>(); // Initialize tables here
    public Hashtable<String, Object> colNameValue;
    static int element;
    public Hashtable<String, String> indexNames;

    public Table(String tableName, String clusteringKeyColumn, Hashtable<String, String> colNameType) {
        this.tableName = tableName;
        this.clusteringKeyColumn = clusteringKeyColumn;
        this.colNameType = colNameType;
        this.colNameValue=new Hashtable<>();
        this.pagesNumber = new ArrayList<Integer>();
        this.indexNames = new Hashtable<>();
    }

    public Hashtable<String, String> getColNameType() {
		return colNameType;
	}

	public String getClusteringKeyColumn() {
		return clusteringKeyColumn;
	}
	
    public String getTableName() {
        return tableName;
    }
    
    public int insert(Hashtable<String, Object> htblColNameValue) throws DBAppException  {
        Page targetPage = null;
        Page page = null;
        int counter = 1;
        for (int i = 0; i < pagesNumber.size(); i++) {
			try (FileInputStream fileIn = new FileInputStream(counter +".ser");
				     ObjectInputStream in = new ObjectInputStream(fileIn)) {
				page = (Page) in.readObject();
				} catch (IOException | ClassNotFoundException e) {
				    e.printStackTrace();
				}
            if (!page.isFull()) {
                targetPage = page;
                break;
            }
            try (FileOutputStream fileOut = new FileOutputStream(counter + ".ser");
      	             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
      	            out.writeObject(page);
      	        } catch (IOException e) {
      	            e.printStackTrace();
      	            throw new DBAppException("Error serializing table: " + e.getMessage());
      	        }
            counter++;
        }

        if (targetPage == null) {
            targetPage = new Page(); 
            pagesNumber.add(counter);
        }
        
        targetPage.insertTuple(htblColNameValue, this);
        
        try (FileOutputStream fileOut = new FileOutputStream(counter +".ser");
			     ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
			    out.writeObject(targetPage);
			} catch (IOException e) {
			    e.printStackTrace();
			}
        return counter;
    }

    public Hashtable<Object, Integer> update(String clusteringKeyValue, Hashtable<String, Object> htblColNameValue) throws DBAppException  {
        Page targetPage = null;
        Page page=null;
        Tuple targetTuple = null;
        Hashtable<String, Object> newHash = new Hashtable<>();
        Tuple oldValue = new Tuple(newHash);
        int pageNum =0;
        Hashtable <Object, Integer> result = new Hashtable<>();
        
        int counter=0;
        for (int i = 0; i < pagesNumber.size(); i++) {
            try (FileInputStream fileIn = new FileInputStream(pagesNumber.get(i) + ".ser");
                 ObjectInputStream in = new ObjectInputStream(fileIn)) {
                page = (Page) in.readObject();
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }

            targetTuple = page.getTupleByClusteringKey(clusteringKeyValue, this.clusteringKeyColumn);
            if (targetTuple != null) {
                targetPage = page;
                pageNum = pagesNumber.get(i);
                counter = i;
                break;
            }
        }

        if (targetTuple == null) {
            throw new DBAppException("Error in finding the Tuple");
        }
        oldValue.values.putAll(targetTuple.values);
        result.put(oldValue, pageNum);
        
        targetTuple.updateValues(htblColNameValue, this.clusteringKeyColumn);

        try (FileOutputStream fileOut = new FileOutputStream(pagesNumber.get(counter) + ".ser");
             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
            out.writeObject(targetPage);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

	public int delete(Hashtable<String, Object> htblColNameValue, int index) throws IOException, DBAppException {
		Page page=null;
		int pageNum = index;
    	try (FileInputStream fileIn = new FileInputStream(index +".ser");
			     ObjectInputStream in = new ObjectInputStream(fileIn)) {
			page = (Page) in.readObject();
			} catch (IOException | ClassNotFoundException e) {
			    throw new DBAppException("Error in finding the page");
			}
        boolean flag = page.deleteTuples(htblColNameValue);
        if(page.isEmpty() && flag) {
        	pagesNumber = new ArrayList<Integer>();
        	reArrange(pagesNumber, page);
        	return pageNum;
        }
        if(flag && index==pagesNumber.size()-1) {
        	reArrange(pagesNumber, page);
        	try (FileOutputStream fileOut = new FileOutputStream(index +".ser");
   			     ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
   			    out.writeObject(page);
   			} catch (IOException e) {
   			    e.printStackTrace();
   			}
        	return pageNum;
        }
        if(flag) {
        	reArrange(pagesNumber, page);
            try (FileOutputStream fileOut = new FileOutputStream(index +".ser");
    			     ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
    			    out.writeObject(page);
    			} catch (IOException e) {
    			    e.printStackTrace();
    			}
            return pageNum;
        }
        return pageNum;
    }
	
	public void reArrange(ArrayList<Integer> pagesNumber, Page page) {
	    int expectedPageNumber = 1;
	    ArrayList<Integer> newPagesNumber = new ArrayList<>(pagesNumber.size());
	    
	    for (int i = 0; i < pagesNumber.size(); i++) {
	    	try (FileInputStream fileIn = new FileInputStream(expectedPageNumber+".ser");
  				     ObjectInputStream in = new ObjectInputStream(fileIn)) {
  				page = (Page) in.readObject();
  				} catch (IOException | ClassNotFoundException e) {
  				    e.printStackTrace();
  				}
	        Integer pageNumber = pagesNumber.get(i);
	        if (pageNumber == expectedPageNumber) {
	            // If the page number matches the expected value, no reordering is needed
	            newPagesNumber.add(pageNumber);
	            try (FileOutputStream fileOut = new FileOutputStream(expectedPageNumber + ".ser");
		                 ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
		                out.writeObject(page);
		            } catch (IOException e) {
		                e.printStackTrace();
		            }
	            expectedPageNumber++;           
	        } else {
	            // If the page number is not in the expected sequence, insert the current page at the correct position
	            newPagesNumber.add(expectedPageNumber, pageNumber);
	            try (FileOutputStream fileOut = new FileOutputStream(expectedPageNumber + ".ser");
	                 ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
	                out.writeObject(page);
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	            expectedPageNumber++;
	        }
	    }
	    
	    // Update the original pagesNumber ArrayList
	    pagesNumber.clear();
	    pagesNumber.addAll(newPagesNumber);
	}

	
    public ArrayList<Object> selectalltuples(Table t) {
    	ArrayList<Object> out= new ArrayList<>();
    	Page page = null;
    	for(int i=0; i<pagesNumber.size(); i++) {
    		try (FileInputStream fileIn = new FileInputStream(pagesNumber.get(i)+".ser");
				     ObjectInputStream in = new ObjectInputStream(fileIn)) {
				page = (Page) in.readObject();
				} catch (IOException | ClassNotFoundException e) {
				    e.printStackTrace();
				}
    		out.addAll(page.getTuples());
    	}
    	return out;
    	
    }
    
    public ArrayList<Object> selectColumnTuples(String strTableName, String colName) throws DBAppException {
        ArrayList<Object> result = new ArrayList<>();
        Table table;

        try (FileInputStream fileIn = new FileInputStream(strTableName + ".ser");
             ObjectInputStream in = new ObjectInputStream(fileIn)) {
            table = (Table) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            throw new DBAppException("Error deserializing table: " + e.getMessage());
        }

        Hashtable<String, Object> hash = table.getColNameValue();
        Object columnValue = hash.get(colName);
        if (columnValue != null) {
            result.add(columnValue);
        } else {
            return new ArrayList<>();
        }
        

        
        try (FileOutputStream fileOut = new FileOutputStream(strTableName + ".ser");
             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
            out.writeObject(table);
        } catch (IOException e) {
            e.printStackTrace();
            throw new DBAppException("Error serializing table: " + e.getMessage());
        }
        return result;
    }

	public Hashtable<String, Object> getColNameValue() {
		return colNameValue;
	}
}
