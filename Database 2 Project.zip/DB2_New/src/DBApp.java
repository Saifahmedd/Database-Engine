import java.util.Iterator;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;


public class DBApp implements Serializable{
ArrayList<String> tableNames = new ArrayList<>();

	public DBApp( ){
		
	}

	// this does whatever initialization you would like 
	// or leave it empty if there is no code you want to 
	// execute at application startup 
	public void init( ){
		
		
	}


	// following method creates one table only
	// strClusteringKeyColumn is the name of the column that will be the primary
	// key and the clustering column as well. The data type of that column will
	// be passed in htblColNameType
	// htblColNameValue will have the column name as key and the data 
	// type as value
	public void createTable(String strTableName, 
							String strClusteringKeyColumn,  
							Hashtable<String,String> htblColNameType) throws DBAppException{
		try {
			if(tableNames.contains(strTableName)) {
				throw new DBAppException("This table is already exists");
			}
			Table table = new Table(strTableName, strClusteringKeyColumn, htblColNameType);
			try (FileOutputStream fileOut = new FileOutputStream(table.tableName+".ser");
				     ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
				    out.writeObject(table);
				} catch (IOException e) {
				    e.printStackTrace();
				}
			tableNames.add(strTableName);
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}


	// following method creates a B+tree index 
	public void createIndex(String   strTableName,
			String   strColName,
			String   strIndexName) throws DBAppException, ClassNotFoundException{
		
		Table table = null;
        try (FileInputStream fileIn = new FileInputStream(strTableName + ".ser");
	        ObjectInputStream in = new ObjectInputStream(fileIn)) {
	        table = (Table) in.readObject();
	     } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
	        throw new DBAppException("Error deserializing table: " + e.getMessage());
	     	}
  
        if(table.indexNames.containsKey(strColName)) {
        	throw new DBAppException("A index has been created for this column before");
        }
        if(table.indexNames.containsValue(strIndexName)) {
        	throw new DBAppException("This Index Name is used before, Change the name");
        }
        
        if(!table.colNameType.containsKey(strColName)) {
        	throw new DBAppException("This column is not in the Table");
        }
        Hashtable <Object, Integer> keyValue = new Hashtable <Object, Integer>();
        for (int i = 0; i < table.pagesNumber.size(); i++) {
            try (FileInputStream fileIn = new FileInputStream(table.pagesNumber.get(i) + ".ser");
                 ObjectInputStream in = new ObjectInputStream(fileIn)) {
                Page page = (Page) in.readObject();
                
                if (page != null) {
                    for (int j = 0; j < page.getTuples().size(); j++) {
                        if (page.getTuples().get(j) != null) {
                            Tuple t = (Tuple) page.getTuples().get(j);
                            keyValue.put(t.getClusteringKeyValue(strColName), table.pagesNumber.get(i));
                        }
                    }
                }
                try (FileOutputStream fileOut = new FileOutputStream(table.pagesNumber.get(i)+".ser");
          			     ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
          			    out.writeObject(page);
          			} catch (IOException e) {
          			    e.printStackTrace();
          			}
            } catch (IOException e) {
                e.printStackTrace();
                throw new DBAppException("Error deserializing table: " + e.getMessage());
            }
        }

        bplustree b = new bplustree(8);
        for(int i=0; i<keyValue.size(); i++) {
        	Object key = keyValue.keySet().toArray()[i];
        	double value = keyValue.get(key);
        	b.insert(key, value);
        }
        
        table.indexNames.put(strColName, strIndexName);
        
        try (FileOutputStream fileOut = new FileOutputStream(strIndexName+".ser");
 			     ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
 			    out.writeObject(b);
 			} catch (IOException e) {
 			    e.printStackTrace();
 			}
        
        try (FileOutputStream fileOut = new FileOutputStream(strTableName + ".ser");
	             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
	            out.writeObject(table);
	        } catch (IOException e) {
	            e.printStackTrace();
	            throw new DBAppException("Error serializing table: " + e.getMessage());
	        }      
}
	


	// following method inserts one row only. 
	// htblColNameValue must include a value for the primary key
	public void insertIntoTable(String strTableName, Hashtable<String, Object> htblColNameValue) throws DBAppException {
	    
	    Table table = null;
	    int pageNum;
        try (FileInputStream fileIn = new FileInputStream(strTableName + ".ser");
	        ObjectInputStream in = new ObjectInputStream(fileIn)) {
	        table = (Table) in.readObject();
	     } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
	        throw new DBAppException("Error deserializing table: " + e.getMessage());
	     	}

	    try {
	    	if(htblColNameValue.size() != table.colNameType.size()) {
	    		throw new DBAppException("Error in the input of the hashtable");
	    	}
	    	pageNum = table.insert(htblColNameValue);
	    	metaData.saveMetadata(table);
	    }
	    catch (Exception e) {
	        e.printStackTrace();
	        throw new DBAppException("Error inserting into table: " + e.getMessage());
	    }

	        try (FileOutputStream fileOut = new FileOutputStream(strTableName + ".ser");
	             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
	            out.writeObject(table);
	        } catch (IOException e) {
	            e.printStackTrace();
	            throw new DBAppException("Error serializing table: " + e.getMessage());
	        }
	        
	        
	        //B+ Insertion
	        
	        try (FileInputStream fileIn = new FileInputStream(strTableName + ".ser");
		        ObjectInputStream in = new ObjectInputStream(fileIn)) {
		        table = (Table) in.readObject();
		     } catch (IOException | ClassNotFoundException e) {
	            e.printStackTrace();
		        throw new DBAppException("Error deserializing table: " + e.getMessage());
		     	}
	        
	        for(int i=0; i< htblColNameValue.keySet().toArray().length; i++) {
	        	if(table.indexNames.containsKey(htblColNameValue.keySet().toArray()[i])){
	        		String colName = (String) htblColNameValue.keySet().toArray()[i];
	        		Object value = htblColNameValue.get(colName);
	        		bplustree b = null;
	        		try (FileInputStream fileIn = new FileInputStream(table.indexNames.get(colName) + ".ser");
	        		        ObjectInputStream in = new ObjectInputStream(fileIn)) {
	        		        b = (bplustree) in.readObject();
	        		     } catch (IOException | ClassNotFoundException e) {
	        	            e.printStackTrace();
	        		        throw new DBAppException("Error deserializing B+Tree: " + e.getMessage());
	        		     	}
	        		
	        		b.insert(value, pageNum);
	        		try (FileOutputStream fileOut = new FileOutputStream(table.indexNames.get(colName)+".ser");
	        			     ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
	        			    out.writeObject(b);
	        			} catch (IOException e) {
	        			    e.printStackTrace();
	        			}
	        	}
	        }
	        
	        try (FileOutputStream fileOut = new FileOutputStream(strTableName + ".ser");
		             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
		            out.writeObject(table);
		        } catch (IOException e) {
		            e.printStackTrace();
		            throw new DBAppException("Error serializing table: " + e.getMessage());
		        }
	}



	// following method updates one row only
	// htblColNameValue holds the key and new value 
	// htblColNameValue will not include clustering key as column name
	// strClusteringKeyValue is the value to look for to find the row to update.
	public void updateTable(String strTableName, 
							String strClusteringKeyValue,
							Hashtable<String,Object> htblColNameValue   )  throws DBAppException{
		try {
			Hashtable<Object, Integer> oldValue = new Hashtable<Object, Integer>();
			Table table = null;
			Hashtable<String,Object> htblColNameValue2 = new Hashtable<String,Object>();
			try (FileInputStream fileIn = new FileInputStream(strTableName+".ser");
				     ObjectInputStream in = new ObjectInputStream(fileIn)) {
				table = (Table) in.readObject();
				} catch (IOException | ClassNotFoundException e) {
				    e.printStackTrace();
				}
			htblColNameValue2.putAll(htblColNameValue);
			
	        oldValue = table.update(strClusteringKeyValue, htblColNameValue);
	        
	        
	        //Update B+Tree
	        for(int i=0; i< htblColNameValue2.keySet().toArray().length; i++) {
	        	if(table.indexNames.containsKey(htblColNameValue2.keySet().toArray()[i])){
	        		String colName = (String) htblColNameValue2.keySet().toArray()[i];
	        		bplustree b = null;
	        		try (FileInputStream fileIn = new FileInputStream(table.indexNames.get(colName) + ".ser");
	        		     ObjectInputStream in = new ObjectInputStream(fileIn)) {
	        		    b = (bplustree) in.readObject();
	        		} catch (IOException | ClassNotFoundException e) {
	        		    throw new DBAppException("Error deserializing B+ tree: " + e.getMessage());
	        		}

	        		Tuple tuple = (Tuple) oldValue.keySet().toArray()[0];
	        		ArrayList<Double> valueArray = b.search(tuple.values.get(colName));
	        		for(int j=0; j<valueArray.size(); j++) {
	        			double value2 = valueArray.get(j);
	        			int value = (int) value2;
		        		Page page = null;

		        		try (FileInputStream fileIn = new FileInputStream((value) + ".ser");
		        		        ObjectInputStream in = new ObjectInputStream(fileIn)) {
		        		        page = (Page) in.readObject();
		        		     } catch (IOException | ClassNotFoundException e) {
		        	            e.printStackTrace();
		        		        throw new DBAppException("Error deserializing Page: " + e.getMessage());
		        		     	}
		        		
		        		for(int z=0; z<page.getTuples().size(); z++) {
		        			Tuple t = (Tuple) page.getTuples().get(z);
		        			if((int) t.values.get(table.clusteringKeyColumn) == Integer.parseInt(strClusteringKeyValue)) {
		        				Object oldKey = tuple.values.get(colName);
		        				Object newKey = htblColNameValue2.get(colName);	        				
		        				
		        				b.delete(oldKey);
		        				b.insert(newKey, value2);
		        				
		        			}
		        		}	        		
		        		
		        		try (FileOutputStream fileOut = new FileOutputStream(value+".ser");
		        			     ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
		        			    out.writeObject(page);
		        			} catch (IOException e) {
		        			    e.printStackTrace();
		        			}
		        		
		        		try (FileOutputStream fileOut = new FileOutputStream(table.indexNames.get(colName)+".ser");
		        			     ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
		        			    out.writeObject(b);
		        			} catch (IOException e) {
		        			    e.printStackTrace();
		        			}
	        		}	
	        	}
	        }
	        
	        
	     // Serialize the table back
	        try (FileOutputStream fileOut = new FileOutputStream(strTableName + ".ser");
	             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
	            out.writeObject(table);
	        } catch (IOException e) {
	            e.printStackTrace();
	            throw new DBAppException("Error serializing table: " + e.getMessage());
	        }
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}


	// following method could be used to delete one or more rows.
	// htblColNameValue holds the key and value. This will be used in search 
	// to identify which rows/tuples to delete. 	
	// htblColNameValue enteries are ANDED together
	public void deleteFromTable(String strTableName, 
			Hashtable<String,Object> htblColNameValue) throws DBAppException{
	try {
		Table table = null;
		try (FileInputStream fileIn = new FileInputStream(strTableName+".ser");
		 ObjectInputStream in = new ObjectInputStream(fileIn)) {
			table = (Table) in.readObject();
		} catch (IOException | ClassNotFoundException e) {
		e.printStackTrace();
		}
		
		//Delete from B+Tree
		boolean flag = false;
		String colName = null;
		int index=0;
		for(int i=0; i<htblColNameValue.keySet().toArray().length; i++) {
			if((table.indexNames.containsKey(htblColNameValue.keySet().toArray()[i])) && (flag ==false)) {
				colName = (String) htblColNameValue.keySet().toArray()[i];
				bplustree b = null;
				try (FileInputStream fileIn = new FileInputStream(table.indexNames.get(colName) + ".ser");
				     ObjectInputStream in = new ObjectInputStream(fileIn)) {
				    b = (bplustree) in.readObject();
				} catch (IOException | ClassNotFoundException e) {
				    throw new DBAppException("Error deserializing B+ tree: " + e.getMessage());
				}
				double index1 = b.search(htblColNameValue.get(colName)).get(0);
				index = (int) index1;
				
				b.delete(htblColNameValue.get(colName));
        		        		
        		try (FileOutputStream fileOut = new FileOutputStream(table.indexNames.get(colName)+".ser");
       			     ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
       			    out.writeObject(b);
       			} catch (IOException e) {
       			    e.printStackTrace();
       			}
        		break;
			}
			
		}
		
		table.delete(htblColNameValue, index);
		
		//Serialize Table
		try (FileOutputStream fileOut = new FileOutputStream(strTableName + ".ser");
	             ObjectOutputStream out = new ObjectOutputStream(fileOut)) {
	            out.writeObject(table);
	        } catch (IOException e) {
	            e.printStackTrace();
	            throw new DBAppException("Error serializing table: " + e.getMessage());
	        }
	}
	catch(Exception e) {
	e.printStackTrace();
	}
}



	public Iterator selectFromTable(SQLTerm[] arrSQLTerms, 
									String[]  strarrOperators) throws DBAppException{
		if (strarrOperators.length >= arrSQLTerms.length || arrSQLTerms.length > strarrOperators.length+1) {
			throw new DBAppException("Invalid number of SQL terms or operators.");
		}
        
        if(strarrOperators.length == 0 && arrSQLTerms.length == 1) {
        	SQLTerm sqlTerm = arrSQLTerms[0];
        	
        	String tableName = sqlTerm._strTableName;
			
			String colName = sqlTerm._strColumnName;

			String operator = sqlTerm._strOperator;

			Object value = sqlTerm._objValue;
			
			Table table = null;
			try (FileInputStream fileIn = new FileInputStream(tableName+".ser");
				     ObjectInputStream in = new ObjectInputStream(fileIn)) {
				table = (Table) in.readObject();
				} catch (IOException | ClassNotFoundException e) {
				    e.printStackTrace();
				}
			
        }
		int j=0;
		ArrayList<Object> output = new ArrayList<>();
		ArrayList<Object> output2 = new ArrayList<>();
		ArrayList<Object> result = new ArrayList<>();
		ArrayList<Object> tuples = new ArrayList<Object>();
		
		for (int i = 0; i < arrSQLTerms.length; i++) {
			SQLTerm sqlTerm = arrSQLTerms[i];
			
			String tableName = sqlTerm._strTableName;
			
			String colName = sqlTerm._strColumnName;

			String operator = sqlTerm._strOperator;

			Object value = sqlTerm._objValue;			

			
			Table table = null;
			try (FileInputStream fileIn = new FileInputStream(tableName+".ser");
				     ObjectInputStream in = new ObjectInputStream(fileIn)) {
				table = (Table) in.readObject();
				} catch (IOException | ClassNotFoundException e) {
				    e.printStackTrace();
				}
			
			
			if (table == null) {
				throw new DBAppException("Table '" + tableName + "' does not exist.");
			}
			if(table.indexNames.containsKey(colName)) {
				bplustree b = null;
		        try (FileInputStream fileIn = new FileInputStream(table.indexNames.get(colName) + ".ser");
			        ObjectInputStream in = new ObjectInputStream(fileIn)) {
			         b = (bplustree) in.readObject();
			     } catch (IOException | ClassNotFoundException e) {
		            e.printStackTrace();
			        throw new DBAppException("Error deserializing index: " + e.getMessage());
			     	}
		        if(i%2==0) { //Output
	        		if(i>0 && j == strarrOperators.length-1 && i == arrSQLTerms.length-1) {
	        			String op = strarrOperators[j];
	        			tuples.clear();
	        			ArrayList<Double> valueArray = new ArrayList<Double>();
	        			if(operator.equals("=")) {
			        		valueArray = b.search(value);
	        			}
	        			else {
	        				valueArray = b.search(value, operator);
	        			}
		        		for(int f=0; f<valueArray.size(); f++) {
		        			double key2 = valueArray.get(f);
		        			int key = (int) key2;
				        	
				        	Page page = null;
				        	try (FileInputStream fileIn = new FileInputStream(key + ".ser");
							        ObjectInputStream in = new ObjectInputStream(fileIn)) {
							         page = (Page) in.readObject();
							     } catch (IOException | ClassNotFoundException e) {
						            e.printStackTrace();
							        throw new DBAppException("Error deserializing index: " + e.getMessage());
							     	}
				        	for(int z=0; z<page.getTuples().size(); z++) {
				        		Tuple t = (Tuple) page.getTuples().get(z);
				        		tuples.add(t);
				        	}
				        	output.clear();
							applyOperator(output, tuples, operator, value, colName, table);
		        		}
		        		output2.clear();
		        		output2.addAll(output);
		        		output.clear();
		        		output.addAll(result);
		        		result.clear();
						applyFinalOperator(output, output2, op, result, table);					
						removeDuplicates(result, table);			
	        		}
	        		else {		        		
	        			if(i>0) {
	        				tuples.clear();
	        				ArrayList<Double> valueArray = new ArrayList<Double>();
		        			if(operator.equals("=")) {
				        		valueArray = b.search(value);
		        			}
		        			else {
		        				valueArray = b.search(value, operator);
		        			}
			        		for(int f=0; f<valueArray.size(); f++) {
			        			double key2 = valueArray.get(f);
			        			int key = (int) key2;
					        	
					        	Page page = null;
					        	try (FileInputStream fileIn = new FileInputStream(key + ".ser");
								        ObjectInputStream in = new ObjectInputStream(fileIn)) {
								         page = (Page) in.readObject();
								     } catch (IOException | ClassNotFoundException e) {
							            e.printStackTrace();
								        throw new DBAppException("Error deserializing index: " + e.getMessage());
								     	}
					        	for(int z=0; z<page.getTuples().size(); z++) {
					        		Tuple t = (Tuple) page.getTuples().get(z);
					        		tuples.add(t);
					        	}
					        	output.clear();
								applyOperator(output, tuples, operator, value, colName, table);
			        		}
			        		
			        		removeDuplicates(result, table);
	        			}
	        			else {
	        				tuples.clear();
	        				ArrayList<Double> valueArray = new ArrayList<Double>();
		        			if(operator.equals("=")) {
				        		valueArray = b.search(value);
		        			}
		        			else {
		        				valueArray = b.search(value, operator);
		        			}
			        		for(int f=0; f<valueArray.size(); f++) {
			        			double key2 = valueArray.get(f);
			        			int key = (int) key2;
					        	
					        	Page page = null;
					        	try (FileInputStream fileIn = new FileInputStream(key + ".ser");
								        ObjectInputStream in = new ObjectInputStream(fileIn)) {
								         page = (Page) in.readObject();
								     } catch (IOException | ClassNotFoundException e) {
							            e.printStackTrace();
								        throw new DBAppException("Error deserializing index: " + e.getMessage());
								     	}
					        	for(int z=0; z<page.getTuples().size(); z++) {
					        		Tuple t = (Tuple) page.getTuples().get(z);
					        		tuples.add(t);
					        	}
								applyOperator(output, tuples, operator, value, colName, table);
			        		}
	        			}
	        			removeDuplicates(output, table);
	        			if(arrSQLTerms.length == 1) {
	        				result.addAll(output);
	        			}
	        		}	
		        }
		        else { //Output2
        			if(i>1) {
	        			tuples.clear();		        	
	        			ArrayList<Double> valueArray = new ArrayList<Double>();
	        			if(operator.equals("=")) {
			        		valueArray = b.search(value);
	        			}
	        			else {
	        				valueArray = b.search(value, operator);
	        			}
		        		for(int f=0; f<valueArray.size(); f++) {
		        			double key2 = valueArray.get(f);
		        			int key = (int) key2;
				        	
				        	Page page = null;
				        	try (FileInputStream fileIn = new FileInputStream(key + ".ser");
							        ObjectInputStream in = new ObjectInputStream(fileIn)) {
							         page = (Page) in.readObject();
							     } catch (IOException | ClassNotFoundException e) {
						            e.printStackTrace();
							        throw new DBAppException("Error deserializing index: " + e.getMessage());
							     	}
				        	for(int z=0; z<page.getTuples().size(); z++) {
				        		Tuple t = (Tuple) page.getTuples().get(z);
				        		tuples.add(t);
				        	}
							applyOperator(output2, tuples, operator, value, colName, table);
							String op = strarrOperators[j];
							j++;
							ArrayList<Object> result2 = new ArrayList<>();
							applyFinalOperator(result, output2, op, result2, table);
							output.clear();
							output2.clear();
							result.clear();
							result.addAll(result2);
							
							removeDuplicates(result, table);				
				        }			        		
        			}
        			else {
	        			tuples.clear();		
	        			ArrayList<Double> valueArray = new ArrayList<Double>();
	        			if(operator.equals("=")) {
			        		valueArray = b.search(value);
	        			}
	        			else {
	        				valueArray = b.search(value, operator);
	        			}
		        		for(int f=0; f<valueArray.size(); f++) {
		        			double key2 = valueArray.get(f);
		        			int key = (int) key2;
				        	
				        	Page page = null;
				        	try (FileInputStream fileIn = new FileInputStream(key + ".ser");
							        ObjectInputStream in = new ObjectInputStream(fileIn)) {
							         page = (Page) in.readObject();
							     } catch (IOException | ClassNotFoundException e) {
						            e.printStackTrace();
							        throw new DBAppException("Error deserializing index: " + e.getMessage());
							     	}
				        	for(int z=0; z<page.getTuples().size(); z++) {
				        		Tuple t = (Tuple) page.getTuples().get(z);
				        		tuples.add(t);
				        	}
							applyOperator(output2, tuples, operator, value, colName, table);								
				        }
		        		String op = strarrOperators[j];		        		
						applyFinalOperator(output, output2, op, result, table);
						output.clear();
						output2.clear();
						
						removeDuplicates(result, table);				
						j++;
        			}

        		}		        			        	
		        
			}
			else {				
				tuples.clear();
				tuples.addAll(table.selectalltuples(table));				
				if(i%2 == 0) {
					if(i>0 && j == strarrOperators.length-1 && i == arrSQLTerms.length-1) {  			
	        			ArrayList<Object> result2 = new ArrayList<>();
	        			String op = strarrOperators[j];
	        			output.clear();
						applyOperator(output, tuples, operator, value, colName, table);
						applyFinalOperator(result, output, op, result2, table);
						output.clear();
						output2.clear();
						result.clear();
						result.addAll(result2);
						removeDuplicates(result, table);				
	        		}
					else {
						if(i>0) {
							output.clear();
							applyOperator(output, tuples, operator, value, colName, table);
							String op = strarrOperators[j];
		        			ArrayList<Object> result2 = new ArrayList<>();
		        			
							applyFinalOperator(result, output, op, result2, table);
							result.clear();
							result.addAll(result2);
							removeDuplicates(result, table);
							j++; // From AND To OR						
						}
						else {
							output.clear();
							applyOperator(output, tuples, operator, value, colName, table);
							result.addAll(output);
							removeDuplicates(result, table);
						}						
					}
				}
				else {
					if(i>1) {
						output2.clear();
						applyOperator(output2, tuples, operator, value, colName, table);
						String op = strarrOperators[j];
						ArrayList<Object> result2 = new ArrayList<>();
						applyFinalOperator(result, output2, op, result2, table);
						result.clear();
						output.clear();
						output2.clear();
						result.addAll(result2);
						j++;
						removeDuplicates(result, table);
					}
					output2.clear();
					applyOperator(output2, tuples, operator, value, colName, table);
					String op = strarrOperators[j];
					applyFinalOperator(output, output2, op, result, table);
					output.clear();
					output2.clear();
					removeDuplicates(result, table);				
					j++; // From XOR To AND
				} 
			}
	}
			
		
		Iterator<Object> iterator = result.iterator();
		while (iterator.hasNext()) {
	        System.out.println(iterator.next());
	    }
		return iterator;
		}

	

	public ArrayList<Object> removeDuplicates (ArrayList<Object> result, Table table){
		for(int a=0; a<result.size(); a++) {
			Tuple aa = (Tuple)result.get(a);
			Hashtable<String, Object> ht = (Hashtable<String, Object>) aa.getValues();
			for(int b=0; b<result.size(); b++) {
				if(a!=b) {
					Tuple aa2 = (Tuple)result.get(b);
					Hashtable<String, Object> ht2 = (Hashtable<String, Object>) aa2.getValues();
					if(ht.get(table.clusteringKeyColumn).equals(ht2.get(table.clusteringKeyColumn))) {
						result.remove(b);
					}
				}
			}
		}
		return result;
	}
		
	public ArrayList<Object> applyFinalOperator(ArrayList<Object> output, ArrayList<Object> output2, String op, ArrayList<Object> result, Table table) {
		switch(op) {
			case "OR":
			result.addAll(output);
			for(int i=0; i<output2.size(); i++) {
				if(!result.contains(output2.get(i))) {
					result.add(output2.get(i));
				}
			}
			removeDuplicates(result, table);
			break;
			case "AND":

			for(int i=0; i<output.size(); i++) {
				Tuple t1 = (Tuple) output.get(i);
				Hashtable<String, Object> h1 = (Hashtable<String, Object>)t1.getValues();
				int x = (int) h1.get(table.clusteringKeyColumn);
				for(int j=0; j<output2.size(); j++) {
					Tuple t2 = (Tuple) output2.get(j);
					Hashtable<String, Object> h2 = (Hashtable<String, Object>)t2.getValues();
					int y = (int) h2.get(table.clusteringKeyColumn);
					if(x == y) {
						result.add(output.get(i));
					}
				}
			}
			removeDuplicates(result, table);
			break;
			case "XOR":
				for(int i=0; i<output.size(); i++) {
					Tuple t1 = (Tuple) output.get(i);
					Hashtable<String, Object> h1 = (Hashtable<String, Object>)t1.getValues();
					int x = (int) h1.get(table.clusteringKeyColumn);
					if(output2.size()==0) {
						result.addAll(output);
					}
					for(int j=0; j<output2.size(); j++) {
						Tuple t2 = (Tuple) output2.get(j);
						Hashtable<String, Object> h2 = (Hashtable<String, Object>)t2.getValues();
						int y = (int) h2.get(table.clusteringKeyColumn);
						if(x != y) {
							result.add(output.get(i));
						}
					}
				}
			
				for(int i=0; i<output2.size(); i++) {
					Tuple t1 = (Tuple) output2.get(i);
					Hashtable<String, Object> h1 = (Hashtable<String, Object>)t1.getValues();
					int x = (int) h1.get(table.clusteringKeyColumn);
					if(output.size()==0) {
						result.addAll(output2);
					}
					for(int j=0; j<output.size(); j++) {
						Tuple t2 = (Tuple) output.get(j);
						Hashtable<String, Object> h2 = (Hashtable<String, Object>)t2.getValues();
						int y = (int) h2.get(table.clusteringKeyColumn);
						if(x != y) {
							result.add(output2.get(i));
						}
					}
				}
				removeDuplicates(result, table);
			break;
		}
		return result;
	}
		
	public ArrayList<Object> applyOperator(ArrayList<Object> output, ArrayList<Object> tuples, String operator, Object value, String colName, Table table) {
		for(int i=0; i<tuples.size(); i++) {
			Tuple tuple = (Tuple) tuples.get(i);
			Hashtable<String, Object> ourValue = tuple.values;
			if(ourValue.get(colName) instanceof String) {
				switch(operator) {
				case "=":
				if(ourValue.get(colName).equals(value)) {
					output.add(tuple);
				}
				break;
				case "!=":
				if(!ourValue.get(colName).equals(value)) {
					output.add(tuple);
				}
				break;
				default:
				throw new IllegalArgumentException("Unsupported operator: " + operator);
				}
			}
			
			else {
				switch(operator) {
					case "=":
					if(ourValue.get(colName) instanceof Integer) {
						if((int)ourValue.get(colName) == (int)value) {
							output.add(tuple);
						}
					}
					if(ourValue.get(colName) instanceof Double) {
						if((double)ourValue.get(colName) == (double)value) {
							output.add(tuple);
						}
					}
					break;
					case "!=":
						if(ourValue.get(colName) instanceof Integer) {
							if((int)ourValue.get(colName) != (int)value) {
								output.add(tuple);
							}
						}
						if(ourValue.get(colName) instanceof Double) {
							if((double)ourValue.get(colName) != (double)value) {
								output.add(tuple);
							}
						}
						break;
					case ">":
						if(ourValue.get(colName) instanceof Integer) {
							if((int)ourValue.get(colName) > (int) value) {
								output.add(tuple);
							}
						}
						if(ourValue.get(colName) instanceof Double) {
							if((double) ourValue.get(colName) > (double) value) {
								output.add(tuple);
							}
						}
					break;
					case ">=":
						if(ourValue.get(colName) instanceof Integer) {
							if((int)ourValue.get(colName) >= (int) value) {
								output.add(tuple);
							}
						}
						if(ourValue.get(colName) instanceof Double) {
							if((double) ourValue.get(colName) >= (double) value) {
								output.add(tuple);
							}
						}
					break;
					case "<":
						if(ourValue.get(colName) instanceof Integer) {
							if((int)ourValue.get(colName) < (int) value) {
								output.add(tuple);
							}
						}
						if(ourValue.get(colName) instanceof Double) {
							if((double) ourValue.get(colName) < (double) value) {
								output.add(tuple);
							}
						}
					break;
					case "<=":
						if(ourValue.get(colName) instanceof Integer) {
							if((int)ourValue.get(colName) <= (int) value) {
								output.add(tuple);
							}
						}
						if(ourValue.get(colName) instanceof Double) {
							if((double) ourValue.get(colName) <= (double) value) {
								output.add(tuple);
							}
						}
					break;
					default:
					throw new IllegalArgumentException("Unsupported operator: " + operator);
				}
			}
			
		}
		return output;
	}

	
	public static void main(String[] args) {
	        
	}

}